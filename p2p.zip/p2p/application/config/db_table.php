<?php
$config['user_table'] = 'lms_user';
$config['menu_table'] = 'lms_menus';
?>