<?php

defined('BASEPATH') OR exit('No direct script access allowed');

$config['googleplus']['application_name'] = 'Hotel Booking';
$config['googleplus']['client_id']        = '150823619919-69h8qhrge6j69f2beq2pr97nbaij928d.apps.googleusercontent.com';
$config['googleplus']['client_secret']    = 'YDIghovGUYuy44zTWzi9Paxb';
$config['googleplus']['redirect_uri']     = 'http://democarol.com/hmvc_hotel_booking/login/google_login';
$config['googleplus']['api_key']          = '';
$config['googleplus']['scopes']           = array();

