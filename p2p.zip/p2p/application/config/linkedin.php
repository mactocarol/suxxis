<?php

$config['api_key'] = "754kvejy8gleif";
$config['secret_key'] = "gklO6sSa5RadUr39";
