<?php
$lang["Welcome"]="أهلا بك";


$lang["Home"]="الصفحة الرئيسية";
$lang["About"]="حول";
$lang["Hotels"]="الفنادق";
$lang["Packages"]="الاحزمة";
$lang["Contact"]="اتصل بنا";
// Login Page 
$lang['ADDRESS']='عنوان';
$lang['add_line']='123 الجزر أبجد هوز';
$lang['PHONE']='هاتف';
$lang['no']='1234567890';
$lang['FAX']='الفاكس';
$lang['fax_no']='1234567890';
$lang['EMAIL']='البريد الإلكتروني';
$lang['EMAIL_id']='info@yourmail.com';
$lang['login']='تسجيل الدخول';
$lang['enter_Email']='أدخل البريد الإلكتروني';
$lang['enter_password']='أدخل كلمة المرور';
$lang['Remember_Me']='تذكرنى';
$lang['Forgot_Password']='هل نسيت كلمة المرور؟';
$lang['or_login_with']='أو تسجيل الدخول باستخدام';
$lang['Not_a_member_yet?']='لست عضوا حتى الآن؟';
$lang['Sign-up_Now!']='أفتح حساب الأن!';
//forgot_password.php
$lang['Forgot Password']='هل نسيت كلمة المرور';
$lang['enter Registered Email']='أدخل البريد الإلكتروني المسجل';
$lang['Send Link']='أرسل الرابط';
//reset_password.php
$lang['Reset Password']='إعادة تعيين كلمة المرور';
$lang['Enter Password']='أدخل كلمة المرور';
$lang['Conform Password']='تطابق كلمة المرور';
$lang['Reset']='إعادة تعيين';
//sucess_pass.php
$lang['Login now']='تسجيل الدخول الآن';
$lang['Your Password Reset Sucessfully!']='إعادة تعيين كلمة المرور بنجاح!';
$lang['login']='تسجيل الدخول';
$lang['here...!']='هنا...!';
//register_view.php
$lang['sign up now']='أفتح حساب الأن';
$lang['fill in the form below to get access']='ملء النموذج أدناه للوصول';
$lang['Male']='الذكر';
$lang['Female']='إناثا';
$lang['first name']='الاسم الاول';
$lang['last name']='الكنية';
$lang['Mobile Number']='رقم الهاتف المحمول';
$lang['email address']='عنوان البريد الإلكتروني';
$lang['City']='مدينة';
$lang['Password']='كلمه السر';
$lang['Confirm Password']='تأكيد كلمة المرور';
$lang['sign me up!']='أشركني!';
//sucess_reg.php
$lang['sign up now']='أفتح حساب الأن';
$lang['Your Registration Sucessfully Done!']='تم التسجيل بنجاح!';
$lang['Login']='تسجيل الدخول';
$lang['here...!']='هنا...!';
//home_view.php
$lang['My account']='حسابي';
$lang['login']='تسجيل الدخول';
$lang['Logout']='الخروج';
$lang['Corporate']='الشركات';
$lang['group package']='مجموعة';
	
?>