<?php
$lang["Welcome"]="Welcome";

$lang["Home"]="HOME";
$lang["About"]="ABOUT";
$lang["Hotels"]="HOTELS";
$lang["Packages"]="PACKAGES";
$lang["Contact"]="CONTACT US";
// Login Page 
$lang['ADDRESS']='ADDRESS';
$lang['add_line']='123 Lorem ipsum dolor sit amet';
$lang['PHONE']='PHONE';
$lang['no']='1234567890';
$lang['FAX']='FAX';
$lang['fax_no']='1234567890';
$lang['EMAIL']='EMAIL';
$lang['EMAIL_id']='info@yourmail.com';
$lang['login']='login';
$lang['enter_Email']='enter Email';
$lang['enter_password']='enter password';
$lang['Remember_Me']='Remember Me';
$lang['Forgot_Password']='Forgot Password?';
$lang['or_login_with']='or login with';
$lang['Not_a_member_yet?']='Not a member yet?';
$lang['Sign-up_Now!']='Sign-up Now!';
//forgot_password.php
$lang['Forgot Password']='Forgot Password';
$lang['enter Registered Email']='enter Registered Email';
$lang['Send Link']='Send Link';
//reset_password.php
$lang['Reset Password']='Reset Password';
$lang['Enter Password']='Enter Password';
$lang['Conform Password']='Conform Password';
$lang['Reset']='Reset';
//sucess_pass.php
$lang['Login now']='Login now';
$lang['Your Password Reset Sucessfully!']='Your Password Reset Sucessfully!';
$lang['Login']='Login';
$lang['here...!']='here...!';
//register_view.php
$lang['sign up now']='sign up now';
$lang['fill in the form below to get access']='fill in the form below to get access';
$lang['Male']='Male';
$lang['Female']='Female';
$lang['first name']='first name';
$lang['last name']='last name';
$lang['Mobile Number']='Mobile Number';
$lang['email address']='email address';
$lang['City']='City';
$lang['Password']='Password';
$lang['Confirm Password']='Confirm Password';
$lang['sign me up!']='sign me up!';
//sucess_reg.php
$lang['sign up now']='sign up now';
$lang['Your Registration Sucessfully Done!']='Your Registration Sucessfully Done!';
$lang['Login']='Login';
$lang['here...!']='here...!';
//home_view.php
$lang['My account']='My account';
$lang['login']='login';
$lang['Logout']='Logout';
$lang['Corporate']='Corporate';
$lang['group package']='group package';



?>