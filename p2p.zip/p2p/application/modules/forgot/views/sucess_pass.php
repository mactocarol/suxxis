</section>

<section class="title_tour">
  <div class="container">
    <h2><?php echo $this->lang->line('Login now'); ?></h2>
    <p><?php echo $this->lang->line('Your Password Reset Sucessfully!'); ?> <a href="<?= base_url('login'); ?>" style="color:red;"><?php echo $this->lang->line('Login'); ?></a><?php echo $this->lang->line('here...!'); ?> </p>
  </div>
</section>

<section class="registration_wrap">
  <div class="container">
    <div class="registration_wrap_inner">

    </div>
  </div>
</section>

