<?php
class News_panel_model extends HT_Model 
{
	function __construct() {
		parent::__construct();		
	}
        
}