<?php
class Payments_model extends HT_Model 
{
	function __construct() {
		parent::__construct();		
	}
    
    
}