<?php
class Testimonial_model extends HT_Model 
{
	function __construct() {
		parent::__construct();		
	}
    
    
}