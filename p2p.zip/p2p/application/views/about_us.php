<section class="banner_title text-center">
	    	<div class="container">
	        		<h3>company profile</h3>
	        		<h2>About us</h2>
	        </div>
	    </section>
	    
	     <section class="main_container">
         	<div class="container">
            	<div class="col-md-5 about_img">
                	<img src="<?php echo base_url('assets/front');?>/images/about1.jpg">
                    <img src="<?php echo base_url('assets/front');?>/images/about2.jpg">
                </div>
                <div class="col-md-7 ">
                	<h2>Let <strong>Tomorrow</strong> Begin <strong>Today</strong></h2>
                    <p>Suxxis is a international phenomenon built on the foundation that drives it, YOU. </p><p>
We firmly believe in the unity that derives from being part of a family which in brief divides all form of inequality. 
Which is the reason we created this platform, so we can serve you, whilst unifying people from all over the world by instilling our principles through OUR Suxxis. 
</p>
<h3>Our Mission</h3>
<ul>
	<li>To deliver a sustainable platform that will help you realise your financial goals.</li>
    <li>To make money simple and fair for everyone by enabling people to do more with their money and take control of their finances.</li>
    <li>To provide quality services to our users whilst maintaining the highest standards of ethical behaviour. </li>
    <li>To be an innovative, by developing a unique way to generate capital for people</li>
</ul>
<p>Remember, that past performance is not a reliable indicator of future performance, therefore your capital is at risk. <strong>Invest wisely. </strong>
</p>

<a href="<?php echo site_url('user/user_register');?>" class="btn-main yellow-btn">sign up</a>

                </div>
            </div>
         </section>