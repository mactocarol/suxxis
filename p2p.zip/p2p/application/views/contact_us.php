<section class="banner_title text-center">
	    	<div class="container">
	        		<h3>connect with us</h3>
	        		<h2>get in touch</h2>
	        </div>
	    </section>
	    
	     <section class="address_outer">
         	<div class="container">
            	<div class="col-md-5">
                	<h2>welcome at our place</h2>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the </p>
                    <ul>
                    	<li><strong>postal address :</strong> PO box  16211 collins street west victoria</li>
                        <li><strong>Pty Ltd:</strong> ABN 11 119 159 741</li>
                        <li><strong>Phone :</strong> (654) 332-112-222</li>
                        <li><strong>email :</strong> info@gmail.com</li>	
                    </ul>
                </div>
                <div class="col-md-7">
                	<div class="col-md-12"><h2>mail us your  offers</h2></div>
                    <form class="form-contact" action="/action_page.php">
                    <div class="col-md-4">
                    	<div class="form-group">
                        <input type="text" class="form-control" id="name" placeholder="Name">
                      </div>
                    </div>
                     <div class="col-md-4">
                    	<div class="form-group">
                        <input type="email" class="form-control" id="email" placeholder="Email">
                      </div>
                    </div>
                    <div class="col-md-4">
                    	<div class="form-group">
                        <input type="text" class="form-control" id="sub" placeholder="Subject">
                      </div>
                    </div>
                     <div class="col-md-12">
                    	<div class="form-group">
                        <textarea class="form-control" id="message" placeholder="Message"></textarea>
                      </div>
                    </div>
                    <div class="col-md-12"><button type="submit" class="btn-main yellow-btn">Submit Now</button>
                    </div>
                    </form>
                </div>
            </div>
         </section>
		
	    
		<section id="map">
        	<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d3151.839548856083!2d144.95754141492432!3d-37.817227079751774!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2sin!4v1525268537776" width="1300" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
        </section>
