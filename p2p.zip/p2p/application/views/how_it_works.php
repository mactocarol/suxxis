<section class="banner_title text-center">
	    	<div class="container">
	        			<h3>welcome to our world</h3>
	        		<h2>HOW IT WORKS</h2>
	        </div>
	    </section>
	    
	    
<section class="timeline">
<ul>
<li>
    <div>
    <span class="level_no">Level 1</span>
    <p>2 x 0.011btc = 0.022btc – 0.02btc (upgrade to level 2) = 0.002btc profit per month</p>
    </div>
</li>
<li>
    <div>
    <span class="level_no">Level 2</span>
    <p>4 x 0.021btc = 0.084btc – 0.04btc (upgrade to level 3) = 0.044btc profit per month</p>
    </div>
</li>
<li>
    <div>
    <span class="level_no">Level 3</span>
    <p>8 x 0.04btc = 0.32btc – 0.1btc (upgrade to level 4) = 0.22btc profit per month</p>
    </div>
</li>
<li>
    <div>
    <span class="level_no">Level 4</span>
    <p>16 x 0.1btc = 1.6btc – 0.2btc (upgrade to level 5) = 1.4btc profit per month </p>
    </div>
</li>
<li>
    <div>
    <span class="level_no">Level 5</span>
    <p>32 x 0.2btc = 6.4btc – 0.5btc (upgrade to level 6) = 5.9btc profit per month</p>
    </div>
</li>
<li>
    <div>
    <span class="level_no">Level 6</span>
    <p>64 x 0.5btc = 32btc – 1btc (upgrade to level 7) = 31btc profit per month</p>
    </div>
</li>
<li>
    <div>
    <span class="level_no">Level 7</span>
    <p>128 x 1btc = 128btc profit per month </p>
    </div>
</li>

</ul>
</section>