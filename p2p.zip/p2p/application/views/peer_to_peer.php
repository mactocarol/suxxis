<section class="banner_title text-center">
	    	<div class="container">
	        		
	        		<h2 style="margin:37px 0 0; text-align:left;">Peer to Peer Lending Program </h2>
	        </div>
	    </section>
	    
	     <section class="main_container">
         	<div class="container">
            	<div class="col-md-6 about_img">
                	<img src="<?php echo base_url('assets/front');?>/images/peer.jpg">
                    
                </div>
                <div class="col-md-6 ">
                	<h2>Welcome to  <strong>our P2P </strong> lending program </h2>
                    <p>This is a service we added exclusively for our elite members that have managed to reach the pinnacle of our matrix system 
</p>
<p>Members can enjoy being seamlessly connected to other elite members that want to lend their money to sensible honest borrowers who want to get a better rate then they would at their local financial institution. 
</p>


                </div>
            </div>
         </section>
		
	    <section class="program-outer" style="padding-top:0">
	    		<div class="container">
	    			<div class="title_panel text-center">
	    						<h2 style="text-align:left;">P2P Program stages  </h2>
	    						
	    				</div>
	    			<!--<div class="pricing-home12-warp">
                    	<div class="col-md-4 col-sm-4">
                        	<div class="dt-sc-pr-tb-col minimal ">
                            <div class="dt-sc-tb-header">
                                <div class="icon-wrapper">
                                    <span class="fa fa-user"> </span>
                                </div>
                            	<div class="dt-sc-tb-title"><h5>Executive</h5><p>lending program</p></div>
                            	<div class="dt-sc-price">
                                    <p>eligible to lend</p>
                                    <h6> &euro; 1500 <span> / Loan </span></h6>
                                    
                                </div>
                                <ul>
										            <li> 12% growth within a minimum loan  period of 30 days and a maximum of 60 days</li>
										            <li>one loan  only allowed at a time</li>
										            <li>two loans must be  lent and be repaid to upgrade</li>
										            <li>upgrade coast € 150</li>
										        </ul>
                          </div>
                         </div>
                        </div>
                        
                        <div class="col-md-4 col-sm-4">
                        	<div class="dt-sc-pr-tb-col minimal ">
                            <div class="dt-sc-tb-header">
                                <div class="icon-wrapper">
                                    <span class="fa fa-star"> </span>
                                </div>
                            	<div class="dt-sc-tb-title"><h5>star Executive </h5><p>lending program</p></div>
                            	<div class="dt-sc-price">
                                    <p>eligible to lend</p>
                                    <h6> &euro; 3000 <span> / Loan </span></h6>
                                    
                                </div>
                                <ul>
										            <li> 18% growth within a minimum loan  period of 30 days and a maximum of 90 days</li>
										            <li>Two loan  only allowed at a time (simultaneously) up to &euro; 6,000</li>
										            <li>Three loans must be  lent and be repaid to upgrade</li>
										            <li>upgrade coast € 300</li>
										        </ul>
                          </div>
                         </div>
                        </div>
                        
                        <div class="col-md-4 col-sm-4">
                        	<div class="dt-sc-pr-tb-col minimal ">
                            <div class="dt-sc-tb-header">
                                <div class="icon-wrapper">
                                    <span class="fa fa-group"> </span>
                                </div>
                            	<div class="dt-sc-tb-title"><h5>presidential</h5><p>lending program</p></div>
                            	<div class="dt-sc-price">
                                    <p>eligible to lend</p>
                                    <h6> &euro; 5,000 <span> / Loan </span></h6>
                                    
                                </div>
                                <ul>
										            <li> 35% growth within a minimum loan  period of 30 days and a maximum of 120 days</li>
										            <li>Three loans  only allowed at a time (simultaneously) up to &euro; 15,000</li>
										            
										        </ul>
                          </div>
                         </div>
                        </div>
                        
									
									
									
									
								</div>-->
                                <div class="pricing-home12-warp ">
                                <img src="<?php echo base_url('assets/front');?>/images/peer-to-peer.jpg">
                                </div>
	    		</div>
</section>