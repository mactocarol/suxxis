<section class="banner_title text-center">
	    	<div class="container">
	        		<h3>company profile</h3>
	        		<h2>Risk Management</h2>
	        </div>
	    </section>
	    
	     <section class="main_container">
         	<div class="container">
            	<div class="col-md-5 about_img">
                	<img src="<?php echo base_url('assets/front');?>/images/Risk-management1.jpg">
                    <img src="<?php echo base_url('assets/front');?>/images/Risk-management2.jpg">
                </div>
                <div class="col-md-7 ">
                	<h2>LRisk <strong>Management</strong> </h2>
                    <p>Risk Management is a fundamental component of our financial process, especially when presenting it to our consumers. It consists of a series of six steps; 
</p>
            <ul class="list1">
            <li>	Identify </li>
            <li>Analyse and Prioritize</li>
            <li>Plan and Schedule</li>
            <li>Track and Report</li>
            <li>Control</li>
            <li>Learn</li>
            
            </ul>

<p>The RM process helps to prevent problems as they occur, by properly going through these steps extensively. Now if these problems have been envisioned beforehand, then using our six steps we’d have planned ahead and developed contingency’s to properly address them. 
</p>
<p>
	We’ve kept strict focus on valuation, in accordance with the currency we’re going to be utilizing “Verge”. Users will benefit from the price fluctuations that will come from Suxxis using this as the form of payments.  Not only will this generate users another source of income, but they’ll also benefit from the level of security, anonymity and efficiency Verge offers which is precisely the reason we chose to operate using them. </p><p>
Suxxis is only as strong as the people that build it. Therefore, users will learn to trust the people within their team to pay monthly subscriptions on time, to search for new members and not just rely on others and to train new members to do the same. This will be the backbone of our growth. </p><p>
Throughout our P2P lending program, we increased our level of security significantly, so we can properly manage the risk associated between the level of funds that are being used and the individuals involved with these funds to avoid any type of mistakes. More information on this can be found here.  

</p>

<!--<a href="<?php echo site_url('user/user_register');?>" class="btn-main yellow-btn">sign up</a>
-->
                </div>
            </div>
         </section>